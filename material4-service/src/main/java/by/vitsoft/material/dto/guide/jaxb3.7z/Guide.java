package by.vitsoft.material.dto.guide;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement(name = "guide")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Guide", propOrder = {
    "guideInfoOrOperationalInfoOrLookUpInfo"
})
public class Guide extends AbstractGuide {

    @XmlElements({
        @XmlElement(name = "guideInfo", type = GuideInfo.class),
        @XmlElement(name = "operationalInfo", type = OperationalInfo.class),
        @XmlElement(name = "lookUpInfo", type = LookUpInfo.class)
    })
    protected List<Object> guideInfoOrOperationalInfoOrLookUpInfo;

    /**
     * Gets the value of the guideInfoOrOperationalInfoOrLookUpInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the guideInfoOrOperationalInfoOrLookUpInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGuideInfoOrOperationalInfoOrLookUpInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GuideInfo }
     * {@link OperationalInfo }
     * {@link LookUpInfo }
     * 
     * 
     */
    public List<Object> getGuideInfoOrOperationalInfoOrLookUpInfo() {
        if (guideInfoOrOperationalInfoOrLookUpInfo == null) {
            guideInfoOrOperationalInfoOrLookUpInfo = new ArrayList<Object>();
        }
        return this.guideInfoOrOperationalInfoOrLookUpInfo;
    }

}
